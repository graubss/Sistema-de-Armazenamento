package br.com.armazenamento_usuarios;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArmazenamentoUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
