package br.com.armazenamento_usuarios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArmazenamentoUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArmazenamentoUsuariosApplication.class, args);
	}

}
