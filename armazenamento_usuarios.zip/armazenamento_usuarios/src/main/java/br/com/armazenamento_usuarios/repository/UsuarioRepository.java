/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.armazenamento_usuarios.repository;

import br.com.armazenamento_usuarios.model.Usuario;
import java.util.Optional;
import org.springframework.data.repository.CrudRepository;

/**
 *
 * @author glaub
 */
public interface UsuarioRepository extends CrudRepository<Usuario,Long> {

}
