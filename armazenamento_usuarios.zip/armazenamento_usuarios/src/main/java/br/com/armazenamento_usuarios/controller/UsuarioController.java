/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.armazenamento_usuarios.controller;

import br.com.armazenamento_usuarios.model.Usuario;
import br.com.armazenamento_usuarios.repository.UsuarioRepository;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

/**
 *
 * @author glaub
 */
@Controller
public class UsuarioController {
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @GetMapping("/gerenciarUsuarios")
    public String listarUsuarios(Model model) {
        model.addAttribute("listaUsuario", usuarioRepository.findAll());
        return "gerenciar_usuarios";
    }

    @GetMapping("/novoUsuario")
    public String novoUsuario(Model model) {
        model.addAttribute("usuario", new Usuario());
        return "editar_usuario";
    }

    @GetMapping("/editarUsuario/{Id}")
    public String editarUsuario(@PathVariable("Id") long Id, Model model) {
        Optional<Usuario> usuario = usuarioRepository.findById(Id);
        model.addAttribute("usuario", usuario.get());
        return "editar_usuario";
    }

    @PostMapping("/salvarUsuario")
    public String salvarUsuario(Usuario usuario, BindingResult result) {
        if (result.hasErrors()) {
            return "editar_usuario";
        }
        usuarioRepository.save(usuario);
        return "redirect:/gerenciarUsuarios";
    }

    @GetMapping("/excluirUsuarios/{Id}")
    public String excluirUsuarios(@PathVariable("Id") long Id) {
        usuarioRepository.deleteById(Id);
        return "redirect:/gerenciarUsuarios";
    }
}


